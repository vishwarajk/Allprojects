from django.shortcuts import render, redirect
from .models import Product, Supplier, SaleOrder, StockMovement
from .forms import ProductForm, SupplierForm

def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('list_products')
    else:
        form = ProductForm()
    return render(request, 'inventory/add_product.html', {'form': form})

def list_products(request):
    products = Product.objects.all()
    return render(request, 'inventory/list_products.html', {'products': products})

def add_supplier(request):
    if request.method == 'POST':
        form = SupplierForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('list_suppliers')
    else:
        form = SupplierForm()
    return render(request, 'inventory/add_supplier.html', {'form': form})

def list_suppliers(request):
    suppliers = Supplier.objects.all()
    return render(request, 'inventory/list_suppliers.html', {'suppliers': suppliers})

def add_stock_movement(request):
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        quantity = int(request.POST.get('quantity'))
        movement_type = request.POST.get('movement_type')

        product = Product.objects.get(id=product_id)

        if movement_type == "In":
            product.stock += quantity
        elif movement_type == "Out":
            if product.stock >= quantity:
                product.stock -= quantity
            else:
                return render(request, 'inventory/error.html', {'message': 'Insufficient stock!'})

        product.save()
        StockMovement.objects.create(product=product, quantity=quantity, movement_type=movement_type)

        return redirect('list_products')

    return render(request, 'inventory/add_stock_movement.html')

def create_sale_order(request):
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        quantity = int(request.POST.get('quantity'))
        product = Product.objects.get(id=product_id)

        if product.stock >= quantity:
            total_price = product.price * quantity
            SaleOrder.objects.create(product=product, quantity=quantity, total_price=total_price, status='Pending')
            product.stock -= quantity
            product.save()
            return redirect('list_products')
        else:
            return render(request, 'inventory/error.html', {'message': 'Insufficient stock for sale!'})

    return render(request, 'inventory/create_sale_order.html')

def list_sale_orders(request):
    sale_orders = SaleOrder.objects.all()
    return render(request, 'inventory/list_sale_orders.html', {'sale_orders': sale_orders})

def cancel_sale_order(request, sale_order_id):
    try:
        order = SaleOrder.objects.get(id=sale_order_id)
        order.status = 'Cancelled'
        order.save()

        product = order.product
        product.stock += order.quantity
        product.save()

        return redirect('list_sale_orders')
    except SaleOrder.DoesNotExist:
        return render(request, 'inventory/error.html', {'message': 'Sale order not found!'})

def complete_sale_order(request, sale_order_id):
    try:
        order = SaleOrder.objects.get(id=sale_order_id)
        order.status = 'Completed'
        order.save()
        return redirect('list_sale_orders')
    except SaleOrder.DoesNotExist:
        return render(request, 'inventory/error.html', {'message': 'Sale order not found!'})

def stock_level_check(request):
    products = Product.objects.all()
    stock_levels = {product.name: product.stock for product in products}
    return render(request, 'inventory/stock_levels.html', {'stock_levels': stock_levels})
```
This code defines views for adding and listing products, adding and listing suppliers, adding stock movements, creating sale orders, listing sale orders, cancelling and completing sale orders, and checking stock levels.